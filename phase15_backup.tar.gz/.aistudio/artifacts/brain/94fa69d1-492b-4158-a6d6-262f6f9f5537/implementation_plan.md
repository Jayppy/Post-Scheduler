# Unified Multi-Workspace Architecture: Behind The Release, 74 STUDIO Sales Intelligence & Shared AI Provider Manager

Integrate **74 STUDIO Sales Intelligence** as an independent business workspace inside the existing **Behind The Release** scheduler application, governed by one shared server-side **AI Provider Manager** (Google Gemini primary, Groq first fallback, OpenRouter second fallback, plus optional Cloudflare Workers AI restricted strictly to lightweight tasks). Both workspaces enforce strict data isolation, independent model/quota controls, section-manifest long-form verification, and non-destructive staged deployment.

### User Review & Critical Decisions

> [!IMPORTANT]
> **Architecture & Database Compatibility Inspection Report (Confirmed Ready Without Restructuring)**
> Inspection of the scheduler runtime, dependencies, and Firestore security rules confirms:
> 1. **Additive Dual-Workspace Support**: Existing Firestore collections (`/users/{userId}/workspaceConnections`, `/scheduledJobs`, `/publishHistory`, `/marketingProfiles`, `/researchSources`, `/marketingDrafts`) and server vaults require **zero migration, restructuring, or deletion** to add **Workspace B (`74 STUDIO Sales Intelligence`)**.
> 2. **Client SDK vs Admin SDK Clarity**: The application currently uses **only the Firebase Client SDK** (`firebase/auth` + `firebase/firestore`) protected by strict Firestore security rules (`isVerifiedUser()`, `isOwner(userId)`), with **no Firebase Admin SDK** installed on the server. Keeping this boundary prevents server-side rule bypasses while Express endpoints independently verify Firebase ID tokens, workspace ownership, allowed operations, and payload limits.
> 3. **Zero OAuth or Knowledge Base Collision**: Instagram Unified Login, YouTube OAuth offline refresh persistence, publishing workflows, and the existing Behind The Release knowledge base remain untouched and bound solely to **Workspace A**.

- **Refinement 1 — Cloudflare Workers AI Restricted to Lightweight Tasks**: Never used as a general fallback. Initially optional (enabled only after Gemini, Groq, and OpenRouter are verified) and strictly limited to `classification`, `tagging`, `short-summary`, and `simple-structured-extraction`. Long-form articles, sales proposals, buyer-intent analysis, and complex reasoning never route to Cloudflare Workers AI.
- **Refinement 2 — Free-Tier Quota & Budget Isolation**: Both provider-wide and per-workspace daily request/token budgets, cooldown timers, rate-limit warning thresholds, monthly usage summaries, and manual disable toggles ensure a high-volume run in one workspace cannot exhaust the other workspace's quota. The orchestrator **never** selects a paid model or activates paid billing.
- **Refinement 3 — Model Validation & Safe Fallbacks**: Model mappings are validated for availability, free-tier eligibility, context/output limits, and structured-output support prior to dispatch. Fallbacks occur only on `429` quota, `503` unavailability, or timeouts—never silently on `401`/`403`/`400` or invalid models.

---

### 1. Overview & Core Concept

- **What It Does**: Establishes one unified application containing two logically separated business workspaces and one shared AI control plane:
  - **Workspace A — Behind The Release** *(Independent-Artist Education Brand)*: Preserves Social Scheduler, Instagram & YouTube OAuth connections, AI Creative Studio, Marketing Content Studio, Gemini-grounded Research Intelligence, Cross-Platform Copy (LinkedIn, X, Threads, long-form Blog), Content Library, and existing publishing workflows.
  - **Workspace B — 74 STUDIO Sales Intelligence** *(Commercial Sales & Prospect Operations)*: Isolated workspace containing the verified 74 STUDIO business knowledge base, Lead Research & Discovery, Prospect Qualification, Artist/Producer/Songwriter/Label Segmentation, Buyer-Intent Analysis, Pain-Point Analysis, Opportunity Scoring, Service Recommendation Intelligence, Personalized Sales Responses, Section-Verified Proposal Generation, Follow-Up Drafting, Sales Content & Campaign Intelligence, and Lead/Sales Activity History—strictly excluding social publishing or OAuth restoration.
  - **Shared AI Provider Manager**: Central server-side orchestrator and operator dashboard delivering model validation, workspace-isolated quota protection, automatic failover (`Gemini -> Groq -> OpenRouter`, plus optional lightweight `Cloudflare Workers AI`), SSE streaming, and section-manifest long-form verification.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Dual-Workspace Switcher & Visual Separation**:
     - Top sidebar **Workspace Switcher** toggles cleanly between **Behind The Release** and **74 STUDIO Sales Intelligence**, plus a shared **AI Provider Manager** view.
     - **Workspace A** preserves its warm editorial zinc/silver visual posture and navigation.
     - **Workspace B** renders its own slate/cobalt-accented dashboard, top breadcrumb (`74 STUDIO Sales Intelligence / [Sub-View]`), dedicated CTA (`New Lead` / `Draft Proposal`), and seven focused sub-views with zero social publishing controls.
  2. **Shared AI Provider Management Dashboard & Quota Controls**:
     - Global provider panel displays live availability, free-tier model verification status, masked secret readiness (`Configured` / `Missing Secret`—never exposing keys), active cooldown timers, manual **Enable / Disable** switches, **Test Connection** probes, sanitized error history, fallback activity, and **Monthly Usage Summaries**.
     - **Workspace Allocation & Routing Controls** allow independent tuning for **Behind The Release** vs **74 STUDIO Sales Intelligence**: per-workspace daily request limits, per-workspace daily token caps, budget warning thresholds (`75%` / `90%`), per-task model selection (blocking lightweight-only models from complex/long-form tasks), and task-routing visibility.
  3. **Long-Form Generation & Section Manifest Verification**:
     - Both Marketing Content Studio articles and 74 STUDIO sales proposals display a live **Section Completion Manifest** while streaming over SSE: each expected heading shows `generationStatus`, `completionStatus`, active `provider/model` provenance, and word/token counts.
     - If interrupted or truncated, completed sections remain locked and saved, duplicate headings are blocked/stripped, and incomplete sections display `Incomplete — Resume Section` so the operator recovers cleanly without false completion claims.
  4. **74 STUDIO Sales Intelligence Workflow**:
     - Operator maintains verified 74 STUDIO services, qualification criteria, and approved messaging (no invented testimonials, client metrics, or prices) in **74 STUDIO Knowledge Base**.
     - Operator adds or researches prospects, runs **Qualification**, **Segmentation**, **Buyer-Intent**, **Pain-Point Analysis**, **Opportunity Scoring**, and **Service Recommendation**, generates copy-ready **Personalized Responses**, **Follow-Ups**, or **Multi-Section Proposals**, and tracks every interaction in **Lead & Sales Activity History**.

- **Visual Identity & Theme**:
  - *Palette & Surface Discipline*: Dark obsidian `#09090b` canvas, `#0d0d10` rail, `#141418` primary panels with flat `1px` borders (`border-zinc-800`) and zero nested card sandwiches.
  - *Typography & Tabular Numerals*: `Plus Jakarta Sans` headings, `Manrope` `12px–14px` body copy, and `JetBrains Mono` (`tabular-nums`) for all daily/monthly quota meters, token counters, opportunity scores, cooldown countdowns, and timestamps.
  - *Semantic Indicators*: Emerald (`#16A34A`) for verified/within-budget/complete; Amber (`#D97706`) for quota warnings (`>=75%`), active cooldowns, or incomplete sections; Crimson (`#DC2626`) for exhausted workspace budgets, unverified/paid model blocks, or credential errors.

- **Interactive Feedback & State Completeness**:
  - Populated high-density tables (`36px–44px` rows), empty states with primary CTAs, geometry-matched loading skeletons, and live client-side search/segment/status filters across all views.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Strict Provider & Model Validation Gate**
  - *Chosen Approach*: Maintain a validated model registry checking provider catalog availability, explicit `$0` / free-tier eligibility, context/output token bounds, and structured JSON compatibility before dispatching any request—rejecting unverified or paid models rather than silently upgrading.
  - *Why*: Protects against accidental paid billing, deprecated model failures, and malformed structured JSON from incompatible lightweight models.
  - *Alternatives Considered*: Hardcoding static model strings or allowing arbitrary user-typed model IDs without checks—rejected due to cost and reliability risks.

- **Decision 2 — Workspace-Partitioned Quota Ledger & Cooldown Guard**
  - *Chosen Approach*: Track usage in server-side atomic buckets keyed by `(date, month, workspaceId, providerId)` alongside workspace-specific daily request/token limits and provider-wide cooldown windows. Before executing a call, check both provider health/cooldown and the requesting workspace's remaining budget.
  - *Why*: Ensures runaway batch drafting in Behind The Release cannot starve 74 STUDIO Sales Intelligence's daily quota (and vice versa).
  - *Alternatives Considered*: Global-only counters—rejected because one workspace could silently exhaust shared free-tier quotas.

- **Decision 3 — Client SDK Firestore Rules + Independent Server Endpoint Auth**
  - *Chosen Approach*: Keep all browser Firestore reads/writes strictly on the **Firebase Client SDK** governed by `firestore.rules` (no `firebase-admin` rule bypass). On the Express backend, every AI, quota, and Sales Intelligence endpoint independently verifies the caller's Firebase Auth ID token, validates workspace ownership, enforces allowlisted operations and strict request-size limits, and keeps all API keys and raw diagnostic logs strictly server-side.
  - *Why*: Guarantees defense-in-depth without exposing credentials or unrestricted error logs in client-readable Firestore documents.
  - *Alternatives Considered*: Using Firebase Admin SDK across server routes or storing raw provider error dumps in Firestore—rejected because Admin SDK bypasses security rules and client-readable logs risk leakage.

- **Decision 4 — Section-Level Completion Manifest Over HTTP-200 Assumptions**
  - *Chosen Approach*: Every long-form blog or proposal persists an explicit section manifest (`expectedHeading`, `generationStatus`, `completionStatus`, `savedContent`, `providerProvenance`) validated by duplicate-heading detection and trailing completeness verification before transitioning status to `Complete`.
  - *Why*: Guarantees an HTTP `200` with truncated mid-sentence output is never mislabeled as finished work.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                 UNIFIED APP (FIREBASE CLIENT SDK + AUTH)                     │
│                                                                              │
│  ┌──────────────────────────────────┐  ┌──────────────────────────────────┐  │
│  │ WORKSPACE A: BEHIND THE RELEASE  │  │ WORKSPACE B: 74 STUDIO           │  │
│  │ (Protected by firestore.rules)   │  │ SALES INTELLIGENCE               │  │
│  │ • Social Scheduler & IG/YT OAuth │  │ • Verified 74 STUDIO KB          │  │
│  │ • AI Creative Studio             │  │ • Lead Research & Qualification  │  │
│  │ • Marketing Content Studio       │  │ • Segmentation, Intent & Scoring │  │
│  │ • Research Intelligence (Gemini) │  │ • Responses, Proposals & Log     │  │
│  └────────────────┬─────────────────┘  └────────────────┬─────────────────┘  │
│                   └──────────────────┬──────────────────┘                    │
│                                      ▼                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │       SHARED AI PROVIDER DASHBOARD & WORKSPACE QUOTA CONTROLS          │  │
│  └───────────────────────────────────┬────────────────────────────────────┘  │
└──────────────────────────────────────┼───────────────────────────────────────┘
                                       │ Bearer Firebase ID Token + HTTPS / SSE
                                       ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│           EXPRESS SERVER GATEWAY (INDEPENDENT AUTH & SIZE LIMITS)            │
│  [1. Verify ID Token] ─▶ [2. Workspace Access Guard] ─▶ [3. Input Schema]    │
│                                      │                                       │
│                                      ▼                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │                 CENTRAL AI PROVIDER MANAGER                            │  │
│  │  • Model Validator (Free-Tier · Context/Output Caps · JSON Support)    │  │
│  │  • Workspace & Provider Quota Guard (Daily Req/Token + Monthly Log)    │  │
│  │  • Task Policy Router (Grounding=Gemini; Lightweight=CF Optional;      │  │
│  │    Complex/Long-Form=Verified Gemini -> Groq -> OpenRouter Only)       │  │
│  │  • Section Manifest Engine (SSE + Anti-Dup Resume + Final Check)       │  │
│  └───────────┬──────────────────┬───────────────────┬─────────────────────┘  │
│              ▼                  ▼                   ▼                        │
│        Google Gemini          Groq             OpenRouter    [Optional CF AI]│
│     (Primary + Search)    (Fallback #1)       (Fallback #2) (LightweightOnly)│
└──────────────────────────────────────────────────────────────────────────────┘
```

- **Security Boundary & Data Model**:
  - **Client SDK Firestore Collections (Enforced by Security Rules)**:
    - *Workspace A (Preserved)*: `workspaceConnections`, `scheduledJobs`, `publishHistory`, `marketingProfiles`, `researchSources`, `marketingDrafts`.
    - *Workspace B (Isolated)*:
      - `/users/{userId}/salesProfiles/{profileId}` (verified 74 STUDIO services, positioning, qualification criteria—never touching Workspace A).
      - `/users/{userId}/salesLeads/{leadId}` (prospect metadata, segment, pain points, buyer intent, opportunity score, service recommendations).
      - `/users/{userId}/salesOutputs/{outputId}` (sales responses, follow-ups, campaign briefs, and section-manifest proposals).
      - `/users/{userId}/salesActivities/{activityId}` (append-only lead & sales activity history).
    - *Shared Safe Configs*: `/users/{userId}/aiWorkspaceConfigs/{configId}` storing non-secret workspace routing preferences, model selections, and daily budget limits only—zero API keys, zero raw diagnostic logs.
  - **Server-Only Vaults & Independent Route Protection**:
    - API secrets (`GEMINI_API_KEY`, `GROQ_API_KEY`, `OPENROUTER_API_KEY`, and optional `CLOUDFLARE_API_TOKEN` / `CLOUDFLARE_ACCOUNT_ID`), raw HTTP error diagnostics, cooldown timestamps, and authoritative daily/monthly quota ledgers stay strictly server-side.
    - Every Express route validates the Firebase ID token (`Authorization: Bearer`), checks workspace scope (`ws-behind-the-release` vs `ws-74-studio-sales`), rejects cross-workspace resource access, and enforces tight JSON body size caps (`<= 2MB` on AI/Sales routes) alongside strict enum/length schemas.

- **Controlled 7-Phase Implementation & Deployment Sequence**:
  - **Phase 1**: Shared provider adapter interface, model validation registry, quota guard core, and Gemini + Groq adapters with strict error-class fallback (`429`/`503`/timeout only; no silent fallback on `401`/`403`/`400`).
  - **Phase 2**: OpenRouter free-model discovery/adapter, per-workspace daily request/token budgets, monthly usage aggregation, cooldowns, and usage warnings.
  - **Phase 3**: Behind The Release integration (Creative Studio & Marketing Content Studio routed through Workspace A's profile while preserving Gemini `googleSearch` grounding) and full Workspace A regression tests.
  - **Phase 4**: **74 STUDIO Sales Intelligence** workspace (`Workspace B`), verified 74 STUDIO knowledge base, isolated Firestore collections & security rules (`deploy_rules`), and all sales intelligence workflows.
  - **Phase 5**: Shared **AI Provider Management Dashboard**, workspace-specific task routing UI, manual disable/test controls, monthly summaries, and optional lightweight-only Cloudflare Workers AI adapter.
  - **Phase 6**: SSE long-form streaming, **Section-Level Completion Manifest**, duplicate-heading guard, incomplete-section recovery, and final completeness verification across both Marketing articles and Sales proposals.
  - **Phase 7 — Deployment Safety & Verification Gate**:
    - Keep the live production Cloud Run revision serving 100% traffic untouched during build/testing.
    - Deploy and verify a separate test revision (`--no-traffic` / test tag) or isolated staging test check covering live Gemini vs mocked Groq/OpenRouter/Cloudflare tests, Workspace A/B isolation, IG/YT OAuth status, publishing workflows, and Marketing Studio drafts/research.
    - Promote to production only after all regression and isolation checks pass, with an explicit single-command Cloud Run revision rollback procedure documented in the final report alongside the complete audit matrix.
